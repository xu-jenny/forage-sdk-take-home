// import renderer from 'react-test-renderer';
// import FormInput from '../components/FormInput';

// it('renders correctly', () => {
//   const tree = renderer
//     .create(<FormInput />)
//     .toJSON();
//   expect(tree).toMatchSnapshot();
// });